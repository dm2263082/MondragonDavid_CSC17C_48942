#include <iostream>
#include <time.h>
#include <random>
#include <string>
#include <cstdlib>

#include "tree.h"
#include "grue.h"
#include "human.h"

using namespace std;

int main()
{
    const int gridSize = 64;
    const int gridLength = 8;
    Grue player(gridSize,gridLength);
    bool play=true;
    int choice;
    int pos;
    int turns = 0;
    srand(time(NULL));
    system("mode 80, 40");




    //Test code
    cout << "Beginning test example code:\n";
    player.printBorders();
    int currentHP= player.getHealth();
    int currentHunger = player.getHunger();

    cout << "Player item class Grue spawned. \nReturning health:";
    cout << currentHP << endl;

    cout << "Returning Player Hunger value: ";
    cout << currentHunger << endl << endl;

    cout << "Testing player ate(int) function with input 3. New hunger is: ";
    player.ate(3);
    currentHunger = player.getHunger();
    cout << currentHunger << endl;

    cout << "Hunger is reduced by given value, determined by an adventurer's build.\n\n";

    cout << "Testing player starved() function, increasing hunger: \n";
    player.starved();
    currentHunger = player.getHunger();

    cout << "Updated hunger value is now: ";
    cout << currentHunger << endl << endl;

    cout << "Testing random function returning a build between 1 and 3: ";
    int build = rand()%3+1;

    cout << build << endl << endl;

    cout << "Testing human description, item of Human class using basic constructor:" << endl;
    Human food;
    food.getDescription();
    cout << endl;
    food.~Human();

    player.starved();   //Resetting Hunger back to original value
    player.starved();   //It is possible to win near instantly if
    player.starved();   //The player encounters a juicy human on Turn 1

    system("PAUSE");
    system("CLS");
    // End test code


    //Initialize lighting and humans
    int lighting[gridSize];
    Human humans[gridSize];

    for(int i=0; i<gridSize; i++) //Initializes all lighting to pitch black
    {
        lighting[i] = 0;
        humans[i] = Human(-1, gridSize, gridLength);
    }

    cout << "____________________________________________________________________\n";
    cout << "Wecome to A Grue Story!\n";

    cout << "You are a Grue, a creature of the darkness!\n";
    cout << "The time of Zork is over, and humans forgot about your existence.\n";
    cout << "A Grue eats humans for breakfast, lunch and dinner.\n";
    cout << "And dies otherwise! Go forth, and feast!\n";
    cout << "But beware! Humans will occasionally drop torches.\n";
    cout << "Light will harm you, and panicked adventurer flailing will harm you.\n";

    cout << "\nIf your Health hits 0 or your Hunger reaches 15, you lose!\n";
    cout << "Reduce your Hunger to 0 to win!\n";
    cout << "_____________________________________________________________________\n";
    system("PAUSE");
    system("CLS");
    //Start hashing implementation
    cout << "As per 1977 copyright protection, please enter the title of this game\n";
    cout << "to verify your license: ";

    string input;
    getline(cin, input);

    unsigned int hash = 8675309;
    for(int i=0; i<input.length(); i++)
    {
        if(input[i] != ' ')
        {
            hash = hash ^ input[i];
        }
    }
    hash = hash%10000;
    if(hash==5274) //Returned hash value if input is 'A Grue Story'
        cout << "Validated! Starting game." << endl;
    else
    {
        cout << "Copyright was unable to be validated. Thanks for trying!\n";
        play=false; //Shut off for testing
    }

    system("PAUSE");
    system("CLS");

    while(play)
    {
        //Update Map
        pos = player.getPosition();

        cout << "\n        ";
        for(int i=0; i<gridSize;i++)
        {
            if(i==pos)
            {
                cout << "G ";
            }
            else
            {
                cout << lighting[i] << " ";
            }

            if((i+1)%gridLength==0&&i!=0)
                cout << "\n        ";
        }
        cout << "\n\n";


        //Update light damage
        if(lighting[pos]>0)
        {
            if(lighting[pos]==3)
            {
                cout << "The light here is unbearable! You begin to sizzle.\n";
                player.hurt();
                player.hurt();
            }
            else if(lighting[pos]==2)
            {
                cout << "The light here begins to burn your skin.\n";
                player.hurt();
            }
            else
            {
                cout << "The bioluminescent plants still glow.\n";
            }
        }
        else if(lighting[pos]==0)
        {
            cout << "The darkness here feels nice.\n";
        }

        //Notify if human is nearby
        cout << "\nYou encounter...";

        humans[pos].getDescription();


        //Display health and hunger under map
        cout << "\nHealth: " << player.getHealth() <<"     Hunger: " << player.getHunger() << endl;

        //Check if full, starved, or dead before giving options for next turn
        if(player.getHealth()<1)
        {
            cout << "\nYou realize your skin is gone, and soon your consciousness.\n";
            cout << "\nYour survived " << turns << " turns!\n";
            cout << "\nGame Over.\n";

            play=false;
        }
        if(player.getHunger()>15)
        {
            cout << "\nYour hunger literally consumes you. You cease to exist.\n";
            cout << "\nYour survived " << turns << " turns!\n";
            cout << "\nGame Over.\n";

            play=false;
            return 0;
        }
        if(player.getHunger()<1)
        {
            cout << "\nYour stomach is fit to burst! It does. You die. You win!\n";
            cout << "\nYour won in " << turns << " turns!\n";
            cout <<"\nGame Over.\n";

            play=false;
            return 0;
        }

        //Beginning Switch Cases - User input is done here

        cout << "\nWhat would you like to do?\n"
             << "        8.Up\n\n"

             << "4.Left  5.Wait  6.Right\n\n"

             << "        2.Down\n\n";

        if(humans[pos].getBuild()!=0) // Gives eating option, but saves formatting otherwise
            cout << "1.Eat Human\n";
        else
            cout << "\n";


        cout << "0. Exit Game\n\n";

        cout << "Your move: ";
        cin >> choice;


        cout << "\n\n"
             << "__________________________________________________________\n";

        system("CLS");
        switch(choice)
        {
        case 1:
        {
            if(humans[pos].getBuild()!=0) //If option is selected but not valid, will do nothing but waste a turn
            {
                int meal = humans[pos].getBuild();
                player.ate(meal);

                if(meal==3)
                {
                    cout << "They put up a fight, but you feast on the juicy adventurer!\n";
                    player.hurt();
                    player.hurt();
                }
                else if(meal ==2)
                 {
                    cout << "They struggled. You have a deliciously average meal.\n";
                    player.hurt();
                }
                else
                {
                    cout << "Easy pickings! You pick the bony adventurer clean.\n";
                }

                humans[pos] = Human(-1, gridSize, gridLength);
            }
            else
            {
                cout << "\nYou attempt to eat nothing. You succeed.\n";
            }
            break;
        }
        case 2: //Down
        {
            pos = player.move(2);
            break;
        }
        case 4: //Left
        {
            pos = player.move(-1);
            break;
        }
        case 5: //Wait
        {
            pos = player.move(0);
            break;
        }
        case 6: //Right
        {
            pos = player.move(1);
            break;
        }
        case 8: //Up
        {
            pos = player.move(-2);
            break;
        }
        case 0: //Exit
        {
            cout << "Exiting game. Thanks for playing!\n";
            play = false;
            break;
        }
        }

        //Update(reduce) lighting every turn
        for(int i=0; i<gridSize; i++)
        {
            if(lighting[i]>3)
                lighting[i] = 3;
            if(lighting[i]>0)
                lighting[i] = lighting[i]-1;
            else
                lighting[i] = 0;
        }

        //Spawns new humans each turn
        srand(time(NULL));
        int rate = rand()%10;
        for(int i=0;i<rate;i++)
        {
            int spawn = rand()%gridSize;
            if(humans[spawn].getBuild()==0)
                humans[spawn] = Human(gridSize,gridLength);
        }

        for(int i=0; i<gridSize; i++)
        {
            if(humans[i].getBuild()>0)
            {
                //Check if torch can be dropped
                if(humans[i].hasTorch())
                {
                    int dropChance = rand()%100;
                    if(dropChance<20)   //20% chance to drop torch if available
                    {
                        lighting[i] = 3;
                        humans[i].dropTorch();
                    }

                }
                //Function finds new valid tile to move to, takes i for input
                int loc = humans[i].move(i,turns);

                //Write human to new returned tile(if empty), spawn a void human in old [i] tile
                if(loc!=-1 && humans[loc].getBuild()==0)
                {
                    humans[loc] = humans[i];
                    humans[i] = Human(-1,gridSize,gridLength);
                }
                else if(loc==-1)
                    humans[i] = Human(-1,gridSize,gridLength);
            }
        }

        if(choice!=5 || player.getHealth()<player.getMaxHealth())
            if(play)
                player.starved();

        turns++;

    }

    return 0;
}
