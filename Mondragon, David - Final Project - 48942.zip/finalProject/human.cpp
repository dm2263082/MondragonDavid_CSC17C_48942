#include "human.h"

using namespace std;
Human::Human()  //Kept to allow array to initialize, before rewriting with required info
{
    gender=NULL;
    gridSize=NULL;
    gridLength=NULL;
    build=NULL;
}

Human::Human(int s, int l)
{
    srand(time(NULL));
    gender = rand()%2;
    gridSize = s;
    gridLength = l;

    build = rand()%100+1;   //percentage chance of builds
    if(build<25)            //skinny=1, average=2, large=3
        build=1;            //half the time, the build will be average
    else if(build<75)
        build=2;
    else
        build=3;

    borderTop = new Tree(0);
    borderLeft = new Tree(0);
    borderRight = new Tree((s-1));
    borderBottom = new Tree((s-1));

    //create Trees containing grid borders for movement validation
    for(int i=0;i<l;i++)
    {
        borderTop->insert(i);
    }
    for(int i=0;i<s;i=i+l)
    {
        borderLeft->insert(i);
    }
    for(int i=(s-1);i>0;i=i-l)
    {
        borderRight->insert(i);
    }
    for(int i=(s-1);i>(s-l-1);i--)
    {
        borderBottom->insert(i);
    }
}

Human::Human(int g, int s, int l) //Hardcodes a specific build human
{                       //Useful for high hunger grues getting a second chance,
    srand(time(NULL));  //Or creating void human tiles
    gender = g;
    build = 0;

    borderTop = new Tree(0);
    borderLeft = new Tree(0);
    borderRight = new Tree((s-1));
    borderBottom = new Tree((s-1));

    //create Trees containing grid borders for movement validation
    for(int i=0;i<l;i++)
    {
        borderTop->insert(i);
    }
    for(int i=0;i<s;i=i+l)
    {
        borderLeft->insert(i);
    }
    for(int i=(s-1);i>0;i=i-l)
    {
        borderRight->insert(i);
    }
    for(int i=(s-1);i>(s-l-1);i--)
    {
        borderBottom->insert(i);
    }
}

int Human::getBuild()
{
    return build;
}

void Human::getDescription()
{
    string description;

    string g;
    string b;
    if(gender==-1)//nobody
    {
        cout << " nobody. This area is quiet.\n";
        return;
    }
    if(gender==0)
        g = " male ";
    else
        g = " female ";

    switch(build)
    {
    case 1:
    {
        b = " bony ";
        break;
    }
    case 2:
    {
        b = " average ";
        break;
    }
    case 3:
    {
        b = " juicy ";
        break;
    }
    default:
    {
        b = " default ";
    }
    }

    description = " a" + g + "adventurer who looks" + b + "\n";

    cout << description;
}

bool Human::hasTorch()
{
    if (torch>0)
        return true;
    else
        return false;
}

void Human::dropTorch()
{
    torch--;
    if(torch<0)
        torch=0;
}

int Human::move(int loc, int turn)
{
     srand(time(NULL));
     int move = rand() % 5;     //Randomly decides on one of 4 directions

     if(turn&build!=0||move==0) //Movement based on build and no movement choice
         return loc;
     else if(move==1)    //Up
     {
         if(borderTop->find(loc))
             return -1; //Leaves the forest
         else loc = loc - gridLength;

         return loc;
     }
     else if(move==2) //Down
     {
         if(borderBottom->find(loc))
             return -1; //Leaves the forest
         else loc = loc + gridLength;

         return loc;
     }
     else if(move==3)   //Left
     {
         if(borderLeft->find(loc))
             return -1; //Leaves the forest
         else loc = loc - 1;

         return loc;
     }
     else if(move==4)   //Right
     {
         if(borderRight->find(loc))
             return -1; //Leaves the forest
         else loc = loc + 1;

         return loc;
     }
}

Human::~Human()
{

}

