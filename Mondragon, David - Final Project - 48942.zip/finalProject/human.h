#ifndef HUMAN_H
#define HUMAN_H

#include "time.h"
#include <random>
#include <iostream>
#include <string>
#include "tree.h"


class Human
{
public:
    Human();
    Human(int s, int l);
    Human(int, int s, int l);

    int getBuild();
    void getDescription();

    bool hasTorch();
    void dropTorch();

    int move(int, int turn);

    ~Human();
private:
    int gender;
    int build;
    int torch;

    int gridSize;
    int gridLength;

    Tree* borderTop;
    Tree* borderLeft;
    Tree* borderRight;
    Tree* borderBottom;


};

#endif // HUMAN_H
