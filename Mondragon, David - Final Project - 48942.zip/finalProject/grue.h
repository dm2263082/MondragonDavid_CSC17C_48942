#ifndef GRUE_H
#define GRUE_H
#include <iostream>
#include "tree.h"


class Grue
{
public:
    Grue(int s, int l);

    void rested();
    void hurt();

    void ate(int);
    void starved();

    int getHealth();
    int getMaxHealth();

    int getHunger();

    int getPosition();
    int move(int);

    void printBorders();

    ~Grue();

private:
    int gridSize;
    int gridLength;
    int health;
    int healthMax;
    int hunger;
    int position;
    Tree* borderTop;
    Tree* borderLeft;
    Tree* borderRight;
    Tree* borderBottom;
};

#endif // GRUE_H
