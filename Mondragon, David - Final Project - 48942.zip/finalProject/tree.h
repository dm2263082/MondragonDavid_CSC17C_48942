#ifndef TREE_H
#define TREE_H

#include <cstdlib>
#include <iostream>
using namespace std;

class Tree
{
private:
    int data;
    Tree* left;
    Tree* right;
    int depthL;
    int depthR;
public:
    Tree(int n);
    void insert(int n);
    int remove(int n);
    void balance();

    bool find(int n);
    int getMax();
    int getMin();

    void preorder();
    void inOrder();
    void postOrder();
};

#endif // TREE_H
