#include "grue.h"

using namespace std;

Grue::Grue(int s, int l) // Take in values of the grid it is created in for movement math
{
    //s is grid size, l is row width
    gridSize = s;
    gridLength = l;

    health = 20;
    healthMax = 20;
    hunger = 1;
    position = (s+l)/2;   //Center of a grid, using an index


    borderTop = new Tree(0);
    borderLeft = new Tree(0);
    borderRight = new Tree((s-1));
    borderBottom = new Tree((s-1));

    //create Trees containing grid borders for movement validation
    for(int i=0;i<l;i++)
    {
        borderTop->insert(i);
    }
    for(int i=0;i<s;i=i+l)
    {
        borderLeft->insert(i);
    }
    for(int i=(s-1);i>0;i=i-l)
    {
        borderRight->insert(i);
    }
    for(int i=(s-1);i>(s-l-1);i--)
    {
        borderBottom->insert(i);
    }
}

void Grue::rested()
{
    health++;
}


void Grue::hurt()
{
    health--;
}

void Grue::ate(int build)
{
    hunger = hunger-build;
}

void Grue::starved()
{
    hunger++;
    cout << "Time passes, and your hunger grows.\n";
}

int Grue::getHealth()
{

    return health;
}

int Grue::getMaxHealth()
{
    return healthMax;
}

int Grue::getHunger()
{

    return hunger;
}

int Grue::move(int movement) //Checks using math to see if move is valid
{
    if(movement == 1) //move to the right
    {
        if(borderRight->find(position))   //checks if Grue is on the rightmost column already
        {
            cout << "Unable to move right, you can't leave the forest!\n";
        }

        else
            position++;     //If valid, changes position and returns new location

        return position;
    }
    else if(movement == -1) //move left
    {
        if(borderLeft->find(position))   //checks if Grue is on the leftmost column already
        {
            cout << "Unable to move left, you can't leave the forest!\n";
        }

        else
            position--;

        return position;
    }
    else if(movement == -2) //move up
    {
        if(borderTop->find(position))   //checks if Grue is on the top row already
        {
            cout << "Unable to move up, you can't leave the forest!\n";
        }

        else
            position = position - gridLength;

        return position;
    }
    else if(movement == 2) // move down
    {
        if(borderBottom->find(position))   //checks if Grue is on the bottom row already
        {
            cout << "Unable to move down, you can't leave the forest!\n";
        }

        else
            position = position + gridLength;

        return position;
    }
    else if(movement == 0)
    {
        if(health<healthMax)
        {
            cout << "You rest where you are, and regain some health\n";
            this->rested();
        }

        else
            cout << "You rest in this area, and already feel refreshed.\n";
    }
    else
    {
        cout << "Coding error! invalid move entry. Not moving.\n";

        return position;
    }
}

int Grue::getPosition()
{
    return position;
}

void Grue::printBorders()   //For testing purposes
{
    cout << "Printing border trees: \n";
    borderTop->inOrder();
    cout << endl;
    borderLeft->inOrder();
    cout << endl;
    borderRight->inOrder();
    cout << endl;
    borderBottom->inOrder();
    cout << endl;
}

Grue::~Grue()
{

}

