#include "clerk.h"

Clerk::Clerk()
{

}

Clerk::~Clerk()
{

}

