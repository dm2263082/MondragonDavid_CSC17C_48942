#ifndef BINARY_H
#define BINARY_H

#include "hashing.h"
#include "tree.h"


class Binary
{
public:
    Binary();
    ~Binary();
    void demo();
};

#endif // BINARY_H
