#ifndef CLERK_H
#define CLERK_H


class Clerk
{
public:
    Clerk();
    ~Clerk();
};

#endif // CLERK_H
