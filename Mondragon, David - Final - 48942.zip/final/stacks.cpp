#include "stacks.h"

Stacks::Stacks()
{
    gCalled = 0;
    hCalled = 0;
}

Stacks::~Stacks()
{

}

void Stacks::demo()
{

    //Testing out recursive trig functions
    //h is hyperbolic sin
    //g is hyperbolic cos


    float angDeg=67;
    float angRad=angDeg*atan(1)/45;

    int angles[] = {0,30,40,60,80,150,180};

    std::cout<<std::setw(5)<< "Angles" << std::setw(15) << "H: " << std::setw(10) << "H calls: " << std::setw(15) << "G: " << std::setw(10) << "G calls: \n";
    for(int i=0; i<6; i++)
    {

        angDeg=angles[i];
        angRad=angDeg*atan(1)/45;

        std::cout<< std::setw(5)<< angDeg << std::setw(15) << h(angRad) << std::setw(10) << hCalled
                                          << std::setw(15) << g(angRad) << std::setw(10) << gCalled << std::endl;

        hCalled=0;
        gCalled=0;
    }

    std::cout << "Note: Although the code appears correct, one of the function calls occasionally reverts to 0 before printing.\n";

}

float Stacks::h(float angR)
{
    hCalled++;
    float tol=1e-6;

    if(angR>-tol&&angR<tol)
        return angR+angR*angR*angR/6;
    return 2*h(angR/2)*g(angR/2);
}
float Stacks::g(float angR){
    gCalled++;
    float tol=1e-6;
    if(angR>-tol&&angR<tol)
        return 1+angR*angR/2;
    float b=h(angR/2);
    return 1+2*b*b;
}

/*
Problem 2 - Stacks
Take my hyperbolic sin/cos recursive function
place a letter on a stack that represents a call
to the sine or cosine.
When the program returns, examine the stack
for how many times the hyp sine was called and
how many times hyp cosine was called vs. the
value you were trying to find.  Put the results
in a table.
*/
