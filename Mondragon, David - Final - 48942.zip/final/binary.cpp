#include "binary.h"

Binary::Binary()
{

}

Binary::~Binary()
{

}

void Binary::demo()
{
    Hashing h;
    srand(time(NULL));
    std::string initials[1000];
    for(int i=0; i<1000; i++)
        initials[i] = "AAA";

    int charVal;
    for(int i=0; i<1000; i++)
    {
        for(int j=0;j<3;j++)
        {
            charVal = rand()%25;
            charVal += 65;
            initials[i][j] = char(charVal);
        }
    }

    int hashes[1000];
    for(int i=0; i<1000; i++)
    {
        hashes[i]= h.hashInitials(initials[i]);
    }

    std::cout << "Hashes created. Inserting into tree.\n";

    Tree t(500);

    for(int i=0;i<1000;i++)
    {
        t.insert(hashes[i]);
    }
    t.inOrder();

    std::cout << "\nTime to find a hash within the tree is an order n operation, and will be faster.\n"
              << "Given a tree size of 1000, if evenly distributed and balanced, it would result\n"
              << "in a maximum of 10 total operations to navigate the tree, at the lowest leaves.\n\n"
              << "An unsorted list on the otherhand, would on average need 500 operations to find\n"
                 "the correct first initial, and two more operations to confirm the full hash.\n\n";
}

/*
Problem 5 - Binary Trees
Take problem 1 and put each of the 3 letters in
a sorted binary tree.  Compare times/operations to identify a
match.
*/
