#ifndef QUEUES_H
#define QUEUES_H

#include <iostream>

class Queues
{
public:
    Queues();
    ~Queues();

    void addClients(int c);
    void addClerk(int rate);
    void removeClerk();
    void removeClient();
    void runSim();
private:

    int extraClerks;
    int clientsHelped;
    int totalWait;
    int avgWait;
    int interval;
    int customerCount;

    struct clerkNode
    {
            int rate;
            int time;
            clerkNode *next;
    };
    clerkNode *clerkHead;
    clerkNode *clerkWorker;

    struct clientNode
    {
        int waitTime;
        clientNode *next;
    };
    clientNode *clientHead;
    clientNode *clientWorker;
};

#endif // QUEUES_H
