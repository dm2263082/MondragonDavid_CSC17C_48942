#include "queues.h"

Queues::Queues()
{
    interval = 20; //Step count for loop simulation
    customerCount = 0;
    extraClerks = 0;
    clientsHelped = 0;
    totalWait = 0;
    avgWait = 0;
    clientHead=NULL;
    clerkHead=NULL;
}

Queues::~Queues()
{

}

void Queues::addClients(int c)
{
    clientNode *clientPrev;
    for(int i=0; i<c; i++)
    {
        if(clientHead)
        {
            clientWorker = clientHead;
            do
            {
                clientPrev=clientWorker;
            }while((clientWorker=clientWorker->next));

            clientNode *clink = new clientNode;
            clink->waitTime = 0;
            clink->next = NULL;
            clientPrev->next = clink;
        }
        else
        {
            clientNode *clink = new clientNode;
            clink->waitTime = 0;
            clink->next=NULL;
            clientHead = clink;
        }
    }
}
void Queues::addClerk(int rate)
{
    clerkNode *clerkPrev;
    if(clerkHead)
    {
        clerkWorker = clerkHead;
        do
        {
            clerkPrev=clerkWorker;
        }while((clerkWorker=clerkWorker->next));

        clerkNode *clink = new clerkNode;
        clink->rate = rate;
        clink->time = 0;
        clink->next=NULL;
        clerkPrev->next = clink;
    }
    else
    {
        clerkNode *clink = new clerkNode;
        clink->rate = rate;
        clink->time = 0;
        clink->next=NULL;
        clerkHead = clink;
    }
}

void Queues::removeClerk()
{
    clerkNode *clerkPrev;
    if(clerkHead)
    {
        clerkWorker = clerkHead;
        do
        {
            clerkPrev=clerkWorker;
        }while((clerkWorker=clerkWorker->next));
        delete clerkWorker;
        clerkPrev->next = NULL;
    }
}

void Queues::removeClient() // Delete client at the front of the line
{
    clientNode *clientPrev;
    if(clientHead)
    {
        clientPrev = clientHead;
        clientHead = clientHead->next;
        delete clientPrev;
    }

}

void Queues::runSim()
{
    std::cout << "Testing queues for 3600 seconds, in 20 second steps\n"
              << "Text will print during the steps, a summary will follow.\n";
    system("PAUSE");
    std::cout << "Adding Clerks\n";
    addClerk(60);
    addClerk(80);
    addClerk(120);

    std::cout << "Adding 3 clients\n";
    addClients(3);

    std::cout << "Beginning sim\n";
    for(int i=0; i<3600;i=i+20)
    {
        std::cout << "i is: " << i << std::endl;

        customerCount = 0;
        if(clientHead)
        {
            clientWorker=clientHead;
            do  //Check line of customers
            {
                customerCount++;
            }while(clientWorker=clientWorker->next);
        }
        if(customerCount>=5)    // Add another clerk at queue of 5+
        {
            std::cout << "Customer count was greater than 5.\n";
            addClerk(60);
            extraClerks++;
        }
        if(customerCount<=0)    // Return to original 3 clerks once line is gone
        {
            std::cout << "Customer count was 0, removing extra clerks.\n";
            for(int i=0; i<extraClerks; i++)
            {
                removeClerk();
                std::cout << "Removed a clerk.\n";
            }
            extraClerks=0;
        }
        if(i%60==0&&i!=0) //  Add 3 customers every minute mark
        {
            std::cout << "New clients have arrived.\n";
            addClients(3);
        }


        clerkWorker=clerkHead;
        do // Loop through clerks and check for client removal
        {
            if(clerkWorker->time>=clerkWorker->rate)
            {
                clerkWorker->time=0;

                if(customerCount>0)
                {
                    totalWait += clientHead->waitTime;
                    clientsHelped++;
                    removeClient();
                    customerCount--;
                }
                std::cout << "A clerk helped a client.\n";
            }
            clerkWorker->time += interval;
        }while((clerkWorker=clerkWorker->next));


        if(clientHead)
        {
            clientWorker=clientHead;
            do // Loop through clients to process waitTime
            {
                clientWorker->waitTime += interval;
            }while(clientWorker=clientWorker->next);
        }
    }
    avgWait = totalWait/clientsHelped;

    std::cout << "\n\nSimulation ended.\n"
         << "Total clients helped was: " << clientsHelped << std::endl
         << "Total wait time was: " << totalWait << std::endl
         << "Average wait time was: " << avgWait << std::endl << std::endl;
}

/*
Problem 3 - Queues
Let us say you are in a line at the video store
or bank like I was last weekend.  One line,
yet there are 3 clerks/tellers which service
the same line.  Simulate the following,
Clerk 1 - Services customers on the average 1/min
Clerk 2 - Services customers on the average 0.5/min
Clerk 3 - Services customers on the average 0.75/min
Customers - Arrive at 3/minute
When the line gets to 5 customers add one more Clerk
with the same service rate as Clerk 1.  Add one more
clerk similarly for each 5 customers.  Take tellers
away when they have serviced the line according to
how they were added.  For instance, if a 4th clerk
was added to the line because there were 5 customers
waiting then remove the clerk when the customer count
in line goes to zero.
What is my average wait time?
*/
