#ifndef STACKS_H
#define STACKS_H

#include <cstdlib>
#include <ctime>
#include <iostream>
#include <iomanip>
#include <cmath>

class Stacks
{
public:
    Stacks();
    ~Stacks();
    void demo();
    float h(float);
    float g(float);

private:
    int hCalled;
    int gCalled;
};

#endif // STACKS_H
