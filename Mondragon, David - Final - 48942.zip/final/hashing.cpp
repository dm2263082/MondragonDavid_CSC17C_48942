#include "hashing.h"
#include "tree.h"
Hashing::Hashing()
{


}

Hashing::~Hashing()
{

}

int Hashing::hash(char c)
{
    int h;
    h = c;
    h = h%65;

    if(h<3)
        return 2;
    else if(h<6)
        return 3;
    else if(h<9)
        return 4;
    else if(h<12)
        return 5;
    else if(h<15)
        return 6;
    else if(h<19)
        return 7;
    else if(h<22)
        return 8;
    else if(h<26)
        return 9;

    return h;
}

int Hashing::hashInitials(std::string initials)
{
    int code=0;
    int modifier =1;
    for(int i=0; i<initials.length(); i++)
    {
        for(int j=1; j<(initials.length()-i); j++)
        {// Modifies returned hash value to add them to an int properly
            modifier *= 10;
        }

        code += hash(initials[i])*modifier;

        modifier =1;
    }

    return code;
}

void Hashing::print()
{
    srand(time(NULL));
    std::cout << "\nBeginning hashing problem.\n";

    std::cout << hashInitials("DAM");
    std::string initials[1000];
    for(int i=0; i<1000; i++)
        initials[i] = "AAA";

    int charVal;
    for(int i=0; i<1000; i++)
    {
        for(int j=0;j<3;j++)
        {
            charVal = rand()%25;
            charVal += 65;
            initials[i][j] = char(charVal);
        }
        std::cout << initials[i] << std::endl;
    }

    int hashes[1000];
    for(int i=0; i<1000; i++)
    {
        hashes[i]= hashInitials(initials[i]);
        std::cout << hashes[i] << std::endl;
    }

    std::cout << "Running statistics.\n";

    int collisions = 0;
    int totalCollisions = 0;
    int maxCollisions = 0;
    int key;
    int split = 500;
    Tree collided(split);

    for(int i=0;i<1000;i++)
    {
        key = hashes[i];

        if(collided.find(key)==false)
        {
            for(int j=(i+1);j<1000;j++)
            {
                if(hashes[j]==key)
                {
                    if(collided.find(key)==false)
                    {
                        collided.insert(key);
                    }

                    collisions++;
                    totalCollisions++;
                }
            }
            if(collisions>maxCollisions)
                maxCollisions = collisions;
        }
        collisions = 0;
    }

    std::cout << "Number of collisions: " << totalCollisions << std::endl;
    std::cout << "Maximum number of collisions: " << maxCollisions << std::endl;
}

/*
Problem 1 - Hashing
We would like to use initials to locate
an individual.  For instance, MEL should
locate the person Mark E. Lehr.  Note:
this is all upper case.  Generate a hash
function for the above using the numbers
on your telephone.  You know, each letter
has a number associated with it, so examine
your telephone keypad.  Generate 1000
3 letter initials and take statistics on
a file of size 1000 to hold this information.
For instance, how many collisions occured,
max number of collisions, average search
to find the person.

Uses numbers 2-9
Ex: ABC = 222
*/
