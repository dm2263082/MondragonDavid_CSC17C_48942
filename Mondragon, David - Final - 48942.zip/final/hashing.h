#ifndef HASHING_H
#define HASHING_H

#include <iostream>
#include <string>
#include <random>
#include <time.h>
#include "tree.h"

class Hashing
{
public:
    Hashing();
    ~Hashing();
    void print();
    int hash(char c);
    int hashInitials(std::string initials);

private:
    Tree* collided;
};

#endif // HASHING_H
