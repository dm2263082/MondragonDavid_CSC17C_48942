#ifndef SORT_H
#define SORT_H

#include <iostream>
#include <random>
#include "time.h"

class Sort
{
public:
    Sort();
    ~Sort();
    void demo();
    void quickSort(int [], int, int, int&);    // The 3 sorts will now return
    int pivot(int [], int, int, int&);        // number of operations
    void swap(int&, int&);
    void print(int [], const int&);
    void merge(int*,int,const int, const int, int&);
    void merge_sort(int*, const int, const int, int&);
    void heapsort(int [], int, int&);
    void buildheap(int [], int, int&);
    void heapify(int [], int, int, int&);
};

#endif // SORT_H
