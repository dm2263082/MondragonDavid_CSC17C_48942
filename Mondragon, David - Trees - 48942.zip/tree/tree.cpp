#include "tree.h"

Tree::Tree(int n)
{
    data = n;
    left = NULL;
    right = NULL;
    depthL = 0;
    depthR = 0;

}

void Tree::insert(int n)
{
    if(n>data)
    {
        if(right != NULL)
        {
            right->insert(n);
        }
        else
        {
            right = new Tree(n);
            depthR++;
        }
    }
    else if(n<data)
    {
        if(left != NULL)
        {
            left->insert(n);
        }
        else
        {
            left = new Tree(n);
            depthL++;
        }
    }
}

int Tree::remove(int n)
{
    if(n==data)
    {
         if(left)
         {
             data = left->data;
             right = left->right;
             left = left->left;
             depthL--;
         }
         else if(right)
         {
             data = right->data;
             left = right->left;
             right = right->right;
             depthR--;
         }
         else
         {
             return -1;
         }
    }
    else if(n<data)
    {
        if(left)
        {
            int decider = left->remove(n);
            if(decider==-1)
            {
                delete left;
                left = NULL;
            }
        }

    }
    else if(n>data)
    {
        if(right)
        {
            int decider = right->remove(n);
            if(decider==-1)
            {
                delete right;
                right = NULL;
            }
        }
    }
    return 1;
}

void Tree::balance()
{
    int difference = depthL - depthR;
    if(difference>2) // Left large
    {
        left->right->left = left;
        left = left->right;
        left->left->right = NULL;
        left->depthL += 1;
        left->left->depthL -= 1;
    }
    if(difference<-2) // Right large
    {
        right->left->right = right;
        right = right->left;
        right->right->left = NULL;
        right->depthR += 1;
        right->right->depthR -= 1;
    }
}

void Tree::preorder() //Root > Left > Right
{
    cout << data << ", ";
    if(left)
        left->preorder();
    if(right)
        right->preorder();

}

void Tree::inOrder() //Left > Root > Right
{
    if(left)
        left->inOrder();
    cout << data << ", ";
    if(right)
        right->inOrder();
}

void Tree::postOrder() //Left > Right > Root
{
    if(left)
        left->postOrder();
    if(right)
        right->postOrder();
    cout << data << ", ";
}
