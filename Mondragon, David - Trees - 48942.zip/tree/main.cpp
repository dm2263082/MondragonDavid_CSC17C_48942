#include <iostream>
#include <time.h>
#include "tree.h"

using namespace std;

int main()
{
    srand(time(NULL));
    Tree t(rand()%100);

    for(int i=0; i<10; i++)
    {
        int random = rand()%100;
        t.insert(random);
    }

    cout << "Tree randomly generated.\n\nPrinting preorder: \n";
    t.preorder();

    cout << "\n\nInserting 50: \n";
    t.insert(50);
    t.preorder();

    cout << "\nRemoving 50: \n";
    t.remove(50);
    t.preorder();

    cout << "\n\nPrinting preorder: ";
    t.preorder();

    cout << "\n\nPrinting In Order: ";
    t.inOrder();

    cout << "\n\nPrinting Post Order: ";
    t.postOrder();
    cout << endl;
    return 0;
}

